package cmsc355;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;

class Assignment_4_Test {
    ServiceBroker sb = new ServiceBroker();
	
    @Test
    public void testTaxModule() throws IOException {
        String output = sb.Broker("Tax,2020,s,9000").toString();
        assertEquals("[900.00]", output);
    }
    
    @Test
    public void testTaxModule2() throws IOException {
        String output = sb.Broker("Tax,2025,H,100000").toString();
        assertEquals("[]", output);  // this year hasn't happened yet
    }
    
    @Test
    public void testTranslateModule() throws IOException {
        String output = sb.Broker("Trans,Spanish,dog").toString();
        assertEquals("[dog, perro]", output);
    }
    
    @Test
    public void testTranslateModule2() throws IOException {
        String output = sb.Broker("Trans,Spanish,dog,friend").toString();
        assertEquals("[]", output);  // it can't take more than one word at a time to translate
    }
}
